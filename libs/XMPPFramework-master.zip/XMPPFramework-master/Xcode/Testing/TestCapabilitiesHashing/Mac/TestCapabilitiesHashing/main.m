//
//  main.m
//  TestCapabilitiesHashing
//
//  Created by Robbie Hanson on 5/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
