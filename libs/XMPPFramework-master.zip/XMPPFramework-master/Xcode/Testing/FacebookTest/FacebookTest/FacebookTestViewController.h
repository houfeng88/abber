#import <UIKit/UIKit.h>

@interface FacebookTestViewController : UIViewController {
    
}

@property(nonatomic,strong) IBOutlet UILabel *statusLabel;

@end
