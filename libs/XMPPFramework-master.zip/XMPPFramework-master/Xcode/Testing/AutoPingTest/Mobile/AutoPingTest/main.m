//
//  main.m
//  AutoPingTest
//
//  Created by Robbie Hanson on 9/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AutoPingTestAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AutoPingTestAppDelegate class]));
    }
}
